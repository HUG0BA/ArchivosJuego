/**
 * Write a description of class JackType here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public enum JackType  
{
    Flow,
    Fire
}
